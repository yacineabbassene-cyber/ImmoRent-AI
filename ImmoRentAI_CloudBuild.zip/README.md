# ImmoRent AI — compilation APK depuis GitHub

Ce dossier contient un workflow GitHub Actions qui compile automatiquement le projet Android fourni dans `ImmoRentAI_V1.zip`.

## Utilisation
1. Créer un dépôt GitHub.
2. Envoyer `ImmoRentAI_CloudBuild.zip` dans le dépôt.
3. Ouvrir l'onglet **Actions**.
4. Lancer **Build ImmoRent AI APK** avec **Run workflow**.
5. Une fois terminé, ouvrir le workflow puis télécharger l'artifact **ImmoRentAI-debug-apk**.
