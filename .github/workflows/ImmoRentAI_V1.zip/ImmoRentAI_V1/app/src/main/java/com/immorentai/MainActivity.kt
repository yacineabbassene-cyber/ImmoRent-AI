package com.immorentai

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.text.InputType
import android.graphics.Typeface
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var link: EditText
    private lateinit var result: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(36, 40, 36, 40) }
        scroll.addView(box)
        box.addView(section("ImmoRent AI", 30f))
        box.addView(info("Assistant d'analyse immobilière — prototype V1"))
        link = EditText(this).apply {
            hint = "Collez le lien de l'annonce"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        box.addView(link, lp())
        box.addView(Button(this).apply {
            text = "🔎 Analyser l'annonce"
            setOnClickListener { analyzeListing() }
        }, lp())
        box.addView(Button(this).apply {
            text = "🏠 Recherche immobilière"
            setOnClickListener { showSearch() }
        }, lp())
        result = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(result)
        setContentView(scroll)
    }

    private fun analyzeListing() {
        result.removeAllViews()
        val url = link.text.toString().trim()
        if (url.isEmpty()) { toast("Collez d'abord le lien de l'annonce."); return }
        result.addView(section("Analyse du bien", 23f))
        result.addView(info("Lien reçu : $url"))
        result.addView(info("Adresse : recherche automatique à connecter aux sources autorisées"))
        result.addView(info("Données annonce : extraction multi-sites prévue dans la prochaine étape"))
        result.addView(section("Calcul rapide", 20f))
        val price = numberField("Prix d'achat (€)")
        val rent = numberField("Loyer mensuel (€)")
        val charges = numberField("Charges mensuelles (€)")
        result.addView(price); result.addView(rent); result.addView(charges)
        result.addView(Button(this).apply {
            text = "💰 Calculer la rentabilité"
            setOnClickListener {
                val p = price.text.toString().replace(',', '.').toDoubleOrNull() ?: 0.0
                val r = rent.text.toString().replace(',', '.').toDoubleOrNull() ?: 0.0
                val c = charges.text.toString().replace(',', '.').toDoubleOrNull() ?: 0.0
                if (p <= 0 || r <= 0) { toast("Indiquez le prix et le loyer."); return@setOnClickListener }
                result.addView(info("Rendement brut : %.2f %%".format(r * 12 / p * 100)))
                result.addView(info("Rendement après charges : %.2f %%".format((r - c) * 12 / p * 100)))
            }
        }, lp())
        result.addView(Button(this).apply {
            text = "↗️ Ouvrir l'annonce"
            setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        }, lp())
    }

    private fun showSearch() {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(36,40,36,40) }
        scroll.addView(box)
        box.addView(section("Recherche immobilière", 26f))
        val city = EditText(this).apply { hint = "Ville / secteur (ex. Melun)" }
        box.addView(city, lp())
        val max = numberField("Prix maximum (€)")
        box.addView(max)
        val type = EditText(this).apply { hint = "Type (ex. T2/T3)" }
        box.addView(type, lp())
        box.addView(Button(this).apply {
            text = "🔍 Rechercher"
            setOnClickListener { toast("Moteur multi-sources à connecter — critères enregistrés : ${city.text}, ${max.text}, ${type.text}") }
        }, lp())
        setContentView(scroll)
    }

    private fun numberField(h: String) = EditText(this).apply {
        hint = h
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        setPadding(0, 16, 0, 16)
    }
    private fun section(s: String, size: Float) = TextView(this).apply { text = s; textSize = size; typeface = Typeface.DEFAULT_BOLD; setPadding(0, 10, 0, 12) }
    private fun info(s: String) = TextView(this).apply { text = s; textSize = 16f; setPadding(0, 7, 0, 7) }
    private fun lp() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 14 }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
