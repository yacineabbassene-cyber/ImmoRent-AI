# ImmoRent AI — V1 prototype

Prototype Android natif Kotlin.

Déjà inclus :
- accueil ;
- collage d'un lien d'annonce ;
- ouverture du lien ;
- formulaire de recherche ;
- calcul du rendement brut ;
- calcul après charges.

À brancher ensuite :
- extraction multi-sources autorisées ;
- détection des doublons ;
- identification d'adresse ;
- DPE/DVF/cadastre ;
- estimation du loyer ;
- financement/cash-flow ;
- analyse IA ;
- favoris/comparateur/alertes ;
- abonnement ;
- publication Play Store.

Ouvrir le dossier dans Android Studio, synchroniser Gradle puis Build > Build APK(s).
